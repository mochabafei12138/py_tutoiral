
# in和not in

print('x' in 'xyz')  # True
print('x' not in 'xyz')  # False

print(34  in [4,34,10])  # True
print(34 not  in [4,34,10])  # False


# 注意：一般结合if语句使用，for xx in xxx
# 判断一个数据在一个容器中在不在的问题，如果存在，结果时True，反之结果就是False