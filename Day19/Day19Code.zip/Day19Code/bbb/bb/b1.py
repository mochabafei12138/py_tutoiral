name = 'bbbb~~~111'
def func():
    print('函数~~bbb')

def func1():
    print('函数~~bbb~~~111')

def func2():
    print('函数~~bbb~~~222')

def func3():
    print('函数~~bbb~~~333')