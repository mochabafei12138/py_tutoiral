name = 'aaaa~~~111'
def func():
    print('函数~~aaa~~~111')
