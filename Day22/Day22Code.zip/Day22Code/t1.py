print('11111')

print(__name__)