# 1.单行注释
# xxxxxx

# 2.多行注释
'''
xxxxx
xxxxx
xxxxx
xxxx
'''

"""
xxxx
xxxx
xxx
"""
# print()是系统功能，作用是向控制台输出指定的数据
# 注意：print()中的()是英文的
print('hello word~~~~~1111')
print('hello word~~~~2222')
print('hello word~~~~~3333')

# 3，
'''
print('hello word~~~~~1111')
print('hello word~~~~2222')
print('hello word~~~~~3333')
print('hello word~~~~~1111')
print('hello word~~~~2222')
print('hello word~~~~~3333')
print('hello word~~~~~1111')
print('hello word~~~~2222')
print('hello word~~~~~3333')
'''

# 快捷键：选中需要注释的内容------》ctrl + /【Mac:command + /】
# 注意：可以给多行代码添加注释，也可以取消多行代码的注释
# print('hello word~~~~~1111')
# print('hello word~~~~2222')
# print('hello word~~~~~3333')
# print('hello word~~~~~1111')
# print('hello word~~~~2222')
# print('hello word~~~~~3333')
# print('hello word~~~~~1111')
# print('hello word~~~~2222')
# print('hello word~~~~~3333')
