s1 = {1,3,4}
s2 = {3,4,5}
# 1.交集:& 或者intsersection()
print(s1 & s2)
print(s1.intersection(s2))

# 2.并集：| 或者  union()
print(s1 | s2)
print(s1.union(s2))

# 3.差集：- 或者  difference()
print(s1 - s2)
print(s1.difference(s2))
